import scrapy
from ..items import WebscrapeItem
class houseprice(scrapy.Spider):
    name = "rent"
    start_urls = [
        'https://www.nobroker.in/property/sale/bangalore/BTM%20Layout?searchParam=W3sibGF0IjoxMi45MTY1NzU3LCJsb24iOjc3LjYxMDExNjMsInBsYWNlSWQiOiJDaElKTVRDcGtmd1VyanNSUDl6TGRpWG1yX0EiLCJwbGFjZU5hbWUiOiJCVE0gTGF5b3V0In1d&radius=2.0&city=bangalore&locality=BTM%20Layout&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/Electronic%20City?searchParam=W3sibGF0IjoxMi44NDUyMTQ1LCJsb24iOjc3LjY2MDE2OTUsInBsYWNlSWQiOiJDaElKdy1GUWQ0cHNyanNSSGZkYXpnXzhYRW8iLCJwbGFjZU5hbWUiOiJFbGVjdHJvbmljIENpdHkiLCJzaG93TWFwIjpmYWxzZX1d&radius=2.0&city=bangalore&locality=BTM%20Layout&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/Marathahalli?searchParam=W3sibGF0IjoxMi45NTk5OTgsImxvbiI6NzcuNzAxNDQ5LCJwbGFjZUlkIjoiQ2hJSkE5bjFrRElTcmpzUkgzdHZVaE1NZUE4IiwicGxhY2VOYW1lIjoiTWFyYXRoYWhhbGxpIiwic2hvd01hcCI6ZmFsc2V9XQ==&radius=2.0&city=bangalore&locality=BTM%20Layout&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/K%20R%20Puram%20Bus%20Stop?searchParam=W3sibGF0IjoxMy4wMDAwMDI1LCJsb24iOjc3LjY3NjUyOSwicGxhY2VJZCI6IkNoSUpoNEdmQWhZUnJqc1JfYmp2bnJiT3Q4SSIsInBsYWNlTmFtZSI6IksgUiBQdXJhbSBCdXMgU3RvcCIsInNob3dNYXAiOmZhbHNlfV0=&radius=2.0&city=bangalore&locality=BTM%20Layout&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/multiple?searchParam=W3sibGF0IjoxMi43Nzg5NjMsImxvbiI6NzcuNzcwMjAyOSwicGxhY2VJZCI6IkNoSUp6UkVxTnFGeHJqc1JyZ3V1YmJxLTZVYyIsInBsYWNlTmFtZSI6IkF0dGliZWxlIiwic2hvd01hcCI6ZmFsc2V9LHsibGF0IjoxMi44NTc1NTc5LCJsb24iOjc3Ljc4NjQwNTcsInBsYWNlSWQiOiJDaElKZnl2bUgtRnlyanNSRDBOQkxMUlktNUEiLCJwbGFjZU5hbWUiOiJTYXJqYXB1cmEiLCJzaG93TWFwIjpmYWxzZX1d&radius=2.0&city=bangalore&locality=BTM%20Layout&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/Indiranagar?searchParam=W3sibGF0IjoxMi45NzgzNjkyLCJsb24iOjc3LjY0MDgzNTYsInBsYWNlSWQiOiJDaElKa1FOM0dLUVdyanNSTmhCUUpyaEdEN1UiLCJwbGFjZU5hbWUiOiJJbmRpcmFuYWdhciIsInNob3dNYXAiOmZhbHNlfV0=&radius=2.0&city=bangalore&locality=BTM%20Layout&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/Yalahanka%20New%20Town%20Bus%20Stop?searchParam=W3sibGF0IjoxMy4wOTYwMDI5LCJsb24iOjc3LjU4MjExNDE5OTk5OTk5LCJwbGFjZUlkIjoiQ2hJSmgySXpHeG9acmpzUmVrQ0l6VGc1TFo0IiwicGxhY2VOYW1lIjoiWWFsYWhhbmthIE5ldyBUb3duIEJ1cyBTdG9wIn1d&radius=2.0&city=bangalore&locality=Yalahanka%20New%20Town%20Bus%20Stop&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/Malleshwara?searchParam=W3sibGF0IjoxMi45OTQwMDYyLCJsb24iOjc3LjU3MTQ4MzMsInBsYWNlSWQiOiJDaElKWlU2RVl5TVdyanNSc1BjR1E1T2g4YmciLCJwbGFjZU5hbWUiOiJNYWxsZXNod2FyYSIsInNob3dNYXAiOmZhbHNlfV0=&radius=2.0&city=bangalore&locality=Yalahanka%20New%20Town%20Bus%20Stop&propType=AP',
        'https://www.nobroker.in/property/sale/bangalore/Jayanagar?searchParam=W3sibGF0IjoxMi45MzA3NzM1LCJsb24iOjc3LjU4MzgzMDIsInBsYWNlSWQiOiJDaElKMmRkbFo1Z1ZyanNSaDFCT0FhZi1vcnMiLCJwbGFjZU5hbWUiOiJKYXlhbmFnYXIiLCJzaG93TWFwIjpmYWxzZX1d&radius=2.0&city=bangalore&locality=Yalahanka%20New%20Town%20Bus%20Stop&propType=AP',

    ]

    def parse(self,response):
        items = WebscrapeItem()

        items['locality'] = response.xpath('..//span[@class="selected-locality-item"]/text()').extract()
        items["title"] = response.xpath('.//span[@class = "overflow-hidden overflow-ellipsis whitespace-nowrap max-w-80pe po:max-w-full"]/text()').extract()
        items["area"] = response.xpath('.//div[@id = "minRent"]/div/text()').extract()
        items["rent"] = response.xpath('.//div[@id = "roomType"]/text()').extract()
        items["price_per_sqft"] = response.xpath('.//div[@id = "minDeposit"]/div/text()').extract()
        items["facing"] = response.xpath('.//div[@class = "flex-1 border-r border-r-solid border-r-cardbordercolor flex"]/div/div/div/text()').extract()
        items["BHK"] = response.xpath('.//div[@class="flex p-0.5p border-b border-b-solid border-b-cardbordercolor items-center"]/div/div/div[@class = "font-semibold"]/text()').extract()
        items["bathrooms"] = response.xpath('.//div[@class="flex p-0.5p items-center"]/div[@class="flex flex-1 border-r border-r-solid border-r-cardbordercolor"]/div/div[@class ="font-semibold"]/text()').extract()
        items["parking"] = response.xpath('.//div[@class="flex p-0.5p items-center"]/div[@class="flex flex-1 pl-0.5p"]/div/div[@class ="font-semibold"]/text()').extract()

        yield items
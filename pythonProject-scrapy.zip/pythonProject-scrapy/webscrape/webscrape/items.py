# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class WebscrapeItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    title = scrapy.Field()
    area = scrapy.Field()
    rent = scrapy.Field()
    price_per_sqft = scrapy.Field()
    facing = scrapy.Field()
    BHK = scrapy.Field()
    bathrooms = scrapy.Field()
    parking = scrapy.Field()
    locality = scrapy.Field()
